package com.example.myapplication.vue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Announce;
import com.example.myapplication.model.Report;
import com.example.myapplication.outils.MesOutils;
import com.example.testprojet.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class LatestListAdapter extends RecyclerView.Adapter<LatestListAdapter.ViewHolder>{

    //propritées
    private ArrayList<Report> lesReports;
    private Controle controler;
    private Context contexte;

    public LatestListAdapter(ArrayList<Report> lesReports, Context contexte) {
        this.lesReports = lesReports;
        this.contexte = contexte;
    }

    @NonNull
    @Override
    public LatestListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_list_latest,parent,false);
        return new LatestListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LatestListAdapter.ViewHolder holder, int position) {//192.168.1.7/test/logo/1.jpg
        if(!lesReports.get(position).getImage().equals(""))
            Picasso.get().load(lesReports.get(position).getImage()).resize(1000,1000).into(holder.reportsimage);
        if(!lesReports.get(position).getCommentImage().equals(""))
            Picasso.get().load(lesReports.get(position).getCommentImage()).resize(1000,1000).into(holder.reportsimagecomment);
        //Glide.with(contexte).asBitmap().load((mesAnnounces.get(position).getImage_url()).into(holder.authlogo);
        holder.reportsdate.setText(MesOutils.convertDateToString(lesReports.get(position).getDate1()));
        holder.reportstitle.setText(lesReports.get(position).getTitle());
        holder.reportsdesc.setText(lesReports.get(position).getDescription());
        if(!lesReports.get(position).getComment().equals("null"))
        holder.comment.setText(lesReports.get(position).getComment());
        holder.reportsusername.setText("by "+lesReports.get(position).getUsername());
        Integer etat = lesReports.get(position).getEtat();
        if(etat==1)holder.reports.setBackgroundResource(R.drawable.red2);
        else if(etat==2)holder.reports.setBackgroundResource(R.drawable.orange);
        else holder.reports.setBackgroundResource(R.drawable.green2);
    }

    @Override
    public int getItemCount() {
        return lesReports.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView reportstitle;
        TextView reportsdesc;
        TextView reportsdate;
        TextView reportsusername;
        TextView comment;
        ImageView reportsimage;
        ImageView reportsimagecomment;
        RelativeLayout reports;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            reportstitle = itemView.findViewById(R.id.reportstitle);
            reportsdesc = itemView.findViewById(R.id.reportsdesc);
            reportsdate = itemView.findViewById(R.id.reportsdate);
            reportsusername = itemView.findViewById(R.id.reportsusername);
            comment = itemView.findViewById(R.id.reportcomment);
            reportsimage = itemView.findViewById(R.id.reportsimage);
            reportsimagecomment = itemView.findViewById(R.id.reportcommentimage);
            reports = itemView.findViewById(R.id.reports);
        }
    }
}
