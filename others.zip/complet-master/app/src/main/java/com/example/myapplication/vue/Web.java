package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.example.testprojet.R;

public class Web extends AppCompatActivity {
    WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);
        web = findViewById(R.id.web);
        WebSettings webSettings = web.getSettings();
        webSettings.setJavaScriptEnabled(true);
        String postData= "";
        String url = "http://192.168.1.39/newsite/log.php";
        web.postUrl(url,postData.getBytes());
        web.setWebViewClient(new WebViewClient());
        Toast.makeText(this,"Please log in again",Toast.LENGTH_LONG).show();
    }

    boolean dbl = false;

    @Override
    public void onBackPressed() {
        if (dbl) {
            Intent intent = new Intent(this, Login.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            finish();
        }

        this.dbl = true;
        Toast.makeText(this, "Please click BACK again to go back to log", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                dbl=false;
            }
        }, 2000);
    }

}
