package com.example.myapplication.outils;

public interface AsyncResponse {
    void processFinish(String output);
}
