package com.example.myapplication.vue;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

import gr.net.maroulis.library.EasySplashScreen;


public class SplashScreenActivity extends AppCompatActivity {
    HomePage homePage;
    SharedPreferences sharedpreferences;
    Controle controle;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.controle = controle.getInstance(this);
        controle.all();
        homePage = new HomePage();
        controle.announce();
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        username = sharedpreferences.getString("username", null);
        EasySplashScreen config = new EasySplashScreen(SplashScreenActivity.this).withFullScreen().withTargetActivity(Login.class)
                .withSplashTimeOut(500).withBackgroundColor(Color.parseColor("#1a1b29")).withAfterLogoText("MadinaTec").withLogo(R.mipmap.ic_launcher_mine);
        config.getAfterLogoTextView().setTextColor(Color.WHITE);
        View easySplashScreen = config.create();
        setContentView(easySplashScreen);
    }
    @Override
    protected void onPause(){
        super.onPause();
        if(username!=null){
        Toast toast = Toast.makeText(this, "hello  "+username, Toast.LENGTH_LONG);
        View toastView = toast.getView(); // This'll return the default View of the Toast.
        /* And now you can get the TextView of the default View of the Toast. */
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(15);
        toastMessage.setTextColor(Color.GRAY);
        toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_mine, 0, 0, 0);
        toastMessage.setGravity(Gravity.CENTER);
        toastMessage.setCompoundDrawablePadding(5);
        toastView.setBackgroundColor(Color.WHITE);
        toast.setGravity(Gravity.TOP , 0, 0);
        toast.show();
        }
    }
}
