package com.example.myapplication.vue;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Announce;
import com.example.myapplication.outils.MesOutils;
import com.example.testprojet.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AnnounceListAdapter extends RecyclerView.Adapter<AnnounceListAdapter.ViewHolder>{

    //propritées
    private ArrayList<Announce> mesAnnounces;
    private Controle controle;
    private Context contexte;

    public AnnounceListAdapter(ArrayList<Announce> mesAnnounces, Context contexte) {
        this.mesAnnounces = mesAnnounces;
        this.contexte = contexte;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_list_announce,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {//192.168.1.7/test/logo/1.jpg
        if(!mesAnnounces.get(position).getImage_url().equals(""))
        Picasso.get().load(mesAnnounces.get(position).getImage_url()).resize(1000,1000).into(holder.image);
        //Glide.with(contexte).asBitmap().load((mesAnnounces.get(position).getImage_url()).into(holder.authlogo);
        //holder.datetxt.setText(MesOutils.convertDateToString(mesAnnounces.get(position).getDate()));
        holder.title.setText("Announce : "+mesAnnounces.get(position).getTitle());
        holder.announce.setText(mesAnnounces.get(position).getComment());
        if(!mesAnnounces.get(position).getDateD().equals("null"))
            holder.dateD.setText("starts : " + mesAnnounces.get(position).getDateD());
        holder.datetxt.setText(mesAnnounces.get(position).getDate());
        if(!mesAnnounces.get(position).getDateF().equals("null"))
            holder.dateF.setText("ends : " +mesAnnounces.get(position).getDateF());
        if(mesAnnounces.get(position).getLogo()==1)  holder.authlogo.setImageResource(R.drawable.water_logo);
        else if(mesAnnounces.get(position).getLogo()==2)  holder.authlogo.setImageResource(R.drawable.street_logo);
        else if(mesAnnounces.get(position).getLogo()==3)  holder.authlogo.setImageResource(R.drawable.elec_logo);
        else if(mesAnnounces.get(position).getLogo()==4)  holder.authlogo.setImageResource(R.drawable.gaz_logo);
    }

    @Override
    public int getItemCount() {
        return mesAnnounces.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView announce;
        TextView title;
        TextView datetxt;
        TextView dateD;
        TextView dateF;
        ImageView authlogo;
        ImageView image;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            announce = itemView.findViewById(R.id.comment);
            datetxt = itemView.findViewById(R.id.datetxt);
            authlogo = itemView.findViewById(R.id.authlogo);
            image = itemView.findViewById(R.id.image);
            dateD = itemView.findViewById(R.id.dateD);
            dateF = itemView.findViewById(R.id.dateF);
        }
    }
}
