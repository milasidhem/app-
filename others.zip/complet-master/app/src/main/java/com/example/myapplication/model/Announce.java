package com.example.myapplication.model;
import java.util.Date;

public class Announce {

    //proprietes
    private String title;
    private String image_url;
    private String date;
    private String dateD;
    private String dateF;
    private String comment;
    private Integer logo;

    public Announce(String title, String image_url, String date, String dateD, String dateF, String comment, Integer logo) {
        this.title = title;
        this.image_url = image_url;
        this.date = date;
        this.dateD = dateD;
        this.dateF = dateF;
        this.comment = comment;
        this.logo = logo;
    }

    public String getTitle() {
        return title;
    }

    public String getImage_url() {
        return image_url;
    }

    public String getDate() {
        return date;
    }

    public String getComment() {
        return comment;
    }

    public String getDateD() { return dateD; }

    public String getDateF() { return dateF; }

    public Integer getLogo() { return logo; }
}
