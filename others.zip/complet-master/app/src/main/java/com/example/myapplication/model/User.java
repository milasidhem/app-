package com.example.myapplication.model;

import android.provider.ContactsContract;

import org.json.JSONArray;

import java.sql.Struct;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class User {
    //proprietes
    private String name;
    private String lastname;
    private String dateN;
    private String adress;
    private String phone;
    private String email;
    private String username;
    private String password;

    public User(String name, String lastname, String dateN, String adress, String phone, String email, String username, String password) {
        this.name = name;
        this.lastname = lastname;
        this.dateN = dateN;
        this.adress = adress;
        this.phone = phone;
        this.email = email;
        this.username = username;
        this.password = password;
    }

    public User(String username, String password){
        this.username = username;
        this.password = password;
    }

    public JSONArray convertToJSONArrayCheck(){
        List laList = new ArrayList();
        laList.add(username);
        laList.add(password);
        return new JSONArray(laList);
    }

    public JSONArray convertToJSONArray(){
        List laList = new ArrayList();
        laList.add(name);
        laList.add(lastname);
        laList.add(dateN);
        laList.add(adress);
        laList.add(phone);
        laList.add(email);
        laList.add(username);
        laList.add(password);
        return new JSONArray(laList);
    }

}
