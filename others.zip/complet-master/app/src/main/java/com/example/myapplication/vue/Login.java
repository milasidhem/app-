package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class Login extends AppCompatActivity {

    EditText username;
    EditText password;
    Controle controle;
    SharedPreferences sharedpreferences;
    Integer autoSave;
    WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        sharedpreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
        int j = sharedpreferences.getInt("key", 0);
        //Default is 0 so autologin is disabled
        if(j > 0){
            Intent activity = new Intent(getApplicationContext(), HomePage.class);
            startActivity(activity);
        }
        else
            init();
    }

    public void init() {
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        this.controle = Controle.getInstance(this);
        controle.mesRapports.clear();
    }


    public void check(View v){
        if(v==findViewById(R.id.login)){
            String user ;
            String pass ;
            user = username.getText().toString();
            pass = password.getText().toString();
            if(username.getText().toString().isEmpty()||password.getText().toString().isEmpty())
                Toast.makeText(this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            else{
                controle.loginUser(user,pass);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {public void run() { login(); }},1000);
            }
        }
    }

    public void login(){
        if(controle.IS_CHECKED){
            if(controle.TYPE==0){
                autoSave = 1;
                SharedPreferences.Editor editor = sharedpreferences.edit();
                String user = this.username.getText().toString();
                editor.putString("username", user);
                editor.putInt("key", autoSave);
                editor.apply();
                Intent intent = new Intent(this, HomePage.class);
                startActivity(intent);
                showToast(user);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
                finish();
            }
            else{
                Intent intent = new Intent(this, Web.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
            }
        }
        else
            Toast.makeText(this,"username or password inccorect",Toast.LENGTH_LONG).show();
    }

    public void showToast(String username){
        Toast toast = Toast.makeText(this, "hello  "+username, Toast.LENGTH_LONG);
        View toastView = toast.getView(); // This'll return the default View of the Toast.
        /* And now you can get the TextView of the default View of the Toast. */
        TextView toastMessage = (TextView) toastView.findViewById(android.R.id.message);
        toastMessage.setTextSize(15);
        toastMessage.setTextColor(Color.GRAY);
        toastMessage.setCompoundDrawablesWithIntrinsicBounds(R.mipmap.ic_launcher_mine, 0, 0, 0);
        toastMessage.setGravity(Gravity.CENTER);
        toastMessage.setCompoundDrawablePadding(5);
        toastView.setBackgroundColor(Color.WHITE);
        toast.setGravity(Gravity.TOP , 0, 0);
        toast.show();
    }

    public void registre(View v){
        if(v==findViewById(R.id.newtxt)){
            Intent intent = new Intent(this, Registre.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
            finish();
        }
        else if(v==findViewById(R.id.visitor)){
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putBoolean("visitor", true);
            editor.apply();
            Intent intent = new Intent(this, HomePage.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_right);
            finish();
        }
        }
    boolean dbl = false;

    @Override
    public void onBackPressed() {
        if (dbl) {
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);super.onBackPressed();
            return;
        }

        this.dbl = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                dbl=false;
            }
        }, 2000);
    }
}
